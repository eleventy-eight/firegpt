# firegpt
Adds ChatGPT as a default search engine for Firefox.
